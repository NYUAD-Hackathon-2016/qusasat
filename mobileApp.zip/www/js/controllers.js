/* global angular, document, window */
'use strict';

angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $ionicPopover, $timeout) {
    // Form data for the login modal
    $scope.loginData = {};
    $scope.isExpanded = false;
    $scope.hasHeaderFabLeft = false;
    $scope.hasHeaderFabRight = false;

    var navIcons = document.getElementsByClassName('ion-navicon');
    for (var i = 0; i < navIcons.length; i++) {
        navIcons.addEventListener('click', function() {
            this.classList.toggle('active');
        });
    }

    ////////////////////////////////////////
    // Layout Methods
    ////////////////////////////////////////

    $scope.hideNavBar = function() {
        document.getElementsByTagName('ion-nav-bar')[0].style.display = 'none';
    };

    $scope.showNavBar = function() {
        document.getElementsByTagName('ion-nav-bar')[0].style.display = 'block';
    };

    $scope.noHeader = function() {
        var content = document.getElementsByTagName('ion-content');
        for (var i = 0; i < content.length; i++) {
            if (content[i].classList.contains('has-header')) {
                content[i].classList.toggle('has-header');
            }
        }
    };

    $scope.setExpanded = function(bool) {
        $scope.isExpanded = bool;
    };

    $scope.setHeaderFab = function(location) {
        var hasHeaderFabLeft = false;
        var hasHeaderFabRight = false;

        switch (location) {
            case 'left':
                hasHeaderFabLeft = true;
                break;
            case 'right':
                hasHeaderFabRight = true;
                break;
        }

        $scope.hasHeaderFabLeft = hasHeaderFabLeft;
        $scope.hasHeaderFabRight = hasHeaderFabRight;
    };

    $scope.hasHeader = function() {
        var content = document.getElementsByTagName('ion-content');
        for (var i = 0; i < content.length; i++) {
            if (!content[i].classList.contains('has-header')) {
                content[i].classList.toggle('has-header');
            }
        }

    };

    $scope.hideHeader = function() {
        $scope.hideNavBar();
        $scope.noHeader();
    };

    $scope.showHeader = function() {
        $scope.showNavBar();
        $scope.hasHeader();
    };

    $scope.clearFabs = function() {
        var fabs = document.getElementsByClassName('button-fab');
        if (fabs.length && fabs.length > 1) {
            fabs[0].remove();
        }
    };
})

.controller('LoginCtrl', function($scope, $timeout, $stateParams, ionicMaterialInk, user) {
//$scope.user = "";
        $scope.functionCalled = function() {
            //user.id = data;

            console.log("Function is called! " + $scope.user);
            //console.log("Find element by Id " + document.getElementById("userId").value);
            //console.log(document.getElementById("list").firstChild.value);
        }
    $scope.$parent.clearFabs();
    $timeout(function() {
        $scope.$parent.hideHeader();
    }, 0);
    ionicMaterialInk.displayEffect();

        $scope.functionCalled = function(data) {
            user.id = data;

            console.log("Function is called! " + data);
            //console.log("Find element by Id " + document.getElementById("usernameSent").value);
            //console.log(document.getElementById("list").firstChild.value);
        }

})

.controller('FriendsCtrl', function($scope, $stateParams, $timeout, ionicMaterialInk, ionicMaterialMotion) {
    // Set Header
    $scope.$parent.showHeader();
    $scope.$parent.clearFabs();
    $scope.$parent.setHeaderFab('left');

    // Delay expansion
    $timeout(function() {
        $scope.isExpanded = true;
        $scope.$parent.setExpanded(true);
    }, 300);

    // Set Motion
    ionicMaterialMotion.fadeSlideInRight();

    // Set Ink
    ionicMaterialInk.displayEffect();
})

.controller('ProfileCtrl', function($scope, $stateParams, $timeout, $http, ionicMaterialMotion, ionicMaterialInk, user, $cordovaToast) {
    // Set Header
    $scope.$parent.showHeader();
    $scope.$parent.clearFabs();
    $scope.isExpanded = false;
    $scope.$parent.setExpanded(false);
    $scope.$parent.setHeaderFab(false);

    // Set Motion
    $timeout(function() {
        ionicMaterialMotion.slideUp({
            selector: '.slide-up'
        });
    }, 300);

    $timeout(function() {
        ionicMaterialMotion.fadeSlideInRight({
            startVelocity: 3000
        });
    }, 700);

    // Set Ink
    ionicMaterialInk.displayEffect();

        $http.get("js/users.json").success(function(userdata){
                console.log("http success for users!!");
                $scope.data = userdata;
                console.log(userdata)
                $scope.data1 = $scope.data[1];
                console.log("My Username is: " + $scope.data[0].username);
                console.log("The name is: " + user.id);
                if ($scope.data[0].id == user.id)
                    $scope.DataNeeded = $scope.data[0];
                else if ($scope.data[1].id == user.id)
                    $scope.DataNeeded = $scope.data[1];
                else if ($scope.data[2].id == user.id)
                    $scope.DataNeeded = $scope.data[2];
                console.log("My correct Username is: " + $scope.DataNeeded.username);

            }).error(function(err){
                console.log("Error " + err);
            });

    $scope.cashIn = function() {
        $cordovaToast
            .show('تم إرسال القسيمة #123 إلى بريدك', 'short', 'bottom')
            .then(function (success) {

            }, function (error) {
                // error
            });

    }

        $scope.donate = function() {
            $cordovaToast
                .show('شكرا لكم على تبرعكم', 'short', 'bottom')
                .then(function (success) {

                }, function (error) {
                    // error
                });

        }
})

    .controller('MainCtrl', function($ionicPopup, $http, $state, $scope, $stateParams, $timeout, ionicMaterialMotion, ionicMaterialInk, user, i) {
        // Set Header
        $scope.$parent.showHeader();
        $scope.$parent.clearFabs();
        $scope.isExpanded = false;
        $scope.$parent.setExpanded(false);
        $scope.$parent.setHeaderFab(false);

        //$http.get("js/ImageDatabase.json").success(function(images){
        //    console.log("http success for images!!");
        //    $scope.currentImage = images[parseInt(i)].img;
        //    //$scope.currentImage = images[parseInt(i)].img;
        //    i = parseInt(i) + 1;
        //    console.log("This is the url: " + $scope.currentImage);
        //    //$scope.currentImage = "https://drive.google.com/file/d/0B5HBK68qn6CsVHFQU1FCS0RJY00/view?usp=sharing";
        //    //document.getElementById("imageChanged").style.backgroundImage = "$scope.currentImage";
        //    $('myOjbect').css('background-image', 'url(' + $scope.currentImage + ')');



            // Set Motion
            $timeout(function() {
                ionicMaterialMotion.slideUp({
                    selector: '.slide-up'
                });
            }, 300);

            $timeout(function() {
                ionicMaterialMotion.fadeSlideInRight({
                    startVelocity: 3000
                });
            }, 700);

            // Set Ink
            ionicMaterialInk.displayEffect();
        //}).error(function(err){
        //    console.log("Error " + err);
        //});

        $scope.images = ["img/samr.png", "img/arya.jpg", "img/ionic.png"];

        $scope.images = ["img/sample/img001.png",
            "img/sample/img002.png",
            "img/sample/img003.png",
            "img/sample/img004.png",
            "img/sample/img005.png",
            "img/sample/img006.png",
            "img/sample/img007.png",
            "img/sample/img008.png",
            "img/sample/img009.png",
            "img/sample/img010.png",
            "img/sample/img011.png",
            "img/sample/img012.png",
            "img/sample/img013.png",
            "img/sample/img014.png",
            "img/sample/img015.png",
            "img/sample/img016.png",
            "img/sample/img017.png",
            "img/sample/img018.png",
            "img/sample/img019.png",
            "img/sample/img020.png",
            "img/sample/img021.png",
            "img/sample/img022.png",
            "img/sample/img023.png",
            "img/sample/img024.png",
            "img/sample/img025.png",
            "img/sample/img026.png",
            "img/sample/img027.png",
            "img/sample/img028.png",
            "img/sample/img029.png",
            "img/sample/img030.png",
            "img/sample/img031.png",
            "img/sample/img032.png",
            "img/sample/img033.png",
            "img/sample/img034.png",
            "img/sample/img035.png",
            "img/sample/img036.png",
            "img/sample/img037.png",
            "img/sample/img038.png",
            "img/sample/img039.png",
            "img/sample/img040.png",
            "img/sample/img041.png",
            "img/sample/img042.png",
            "img/sample/img043.png",
            "img/sample/img044.png",
            "img/sample/img045.png",
            "img/sample/img046.png",
            "img/sample/img047.png",
            "img/sample/img048.png",
            "img/sample/img049.png",
            "img/sample/img050.png",
            "img/sample/img051.png",
            "img/sample/img052.png",
            "img/sample/img053.png",
            "img/sample/img054.png",
            "img/sample/img055.png",
            "img/sample/img056.png",
            "img/sample/img057.png",
            "img/sample/img058.png",
            "img/sample/img059.png",
            "img/sample/img060.png",
            "img/sample/img061.png",
            "img/sample/img062.png",
            "img/sample/img063.png",
            "img/sample/img064.png",
            "img/sample/img065.png",
            "img/sample/img066.png",
            "img/sample/img067.png",
            "img/sample/img068.png",
            "img/sample/img069.png",
            "img/sample/img070.png",
            "img/sample/img071.png",
            "img/sample/img072.png",
            "img/sample/img073.png",
            "img/sample/img074.png",
            "img/sample/img075.png",
            "img/sample/img076.png",
            "img/sample/img077.png",
            "img/sample/img078.png",
            "img/sample/img079.png",
            "img/sample/img080.png",
            "img/sample/img081.png",
            "img/sample/img082.png",
            "img/sample/img083.png",
            "img/sample/img084.png",
            "img/sample/img085.png",
            "img/sample/img086.png",
            "img/sample/img087.png",
            "img/sample/img088.png",
            "img/sample/img089.png",
            "img/sample/img090.png",
            "img/sample/img091.png",
            "img/sample/img092.png",
            "img/sample/img093.png",
            "img/sample/img094.png",
            "img/sample/img095.png",
            "img/sample/img096.png",
            "img/sample/img097.png",
            "img/sample/img098.png",
            "img/sample/img099.png",
            "img/sample/img100.png",
            "img/sample/img101.png",
            "img/sample/img102.png",
            "img/sample/img103.png",
            "img/sample/img104.png",
            "img/sample/img105.png",
            "img/sample/img106.png",
            "img/sample/img107.png",
            "img/sample/img108.png",
            "img/sample/img109.png",
            "img/sample/img110.png",
            "img/sample/img111.png",
            "img/sample/img112.png",
            "img/sample/img113.png",
            "img/sample/img114.png",
            "img/sample/img115.png",
            "img/sample/img116.png",
            "img/sample/img117.png",
            "img/sample/img118.png",
            "img/sample/img119.png",
            "img/sample/img120.png",
            "img/sample/img121.png",
            "img/sample/img122.png",
            "img/sample/img123.png",
            "img/sample/img124.png",
            "img/sample/img125.png",
            "img/sample/img126.png",
            "img/sample/img127.png",
            "img/sample/img128.png",
            "img/sample/img129.png",
            "img/sample/img130.png",
            "img/sample/img131.png",
            "img/sample/img132.png",
            "img/sample/img133.png",
            "img/sample/img134.png",
            "img/sample/img135.png",
            "img/sample/img136.png",
            "img/sample/img137.png",
            "img/sample/img138.png",
            "img/sample/img139.png",
            "img/sample/img140.png",
            "img/sample/img141.png",
            "img/sample/img142.png",
            "img/sample/img143.png",
            "img/sample/img144.png",
            "img/sample/img145.png",
            "img/sample/img146.png",
            "img/sample/img147.png",
            "img/sample/img148.png",
            "img/sample/img149.png",
            "img/sample/img150.png",
            "img/sample/img151.png",
            "img/sample/img152.png",
            "img/sample/img153.png",
            "img/sample/img154.png",
            "img/sample/img155.png",
            "img/sample/img156.png",
            "img/sample/img157.png",
            "img/sample/img158.png",
            "img/sample/img159.png",
            "img/sample/img160.png",
            "img/sample/img161.png",
            "img/sample/img162.png",
            "img/sample/img163.png",
            "img/sample/img164.png",
            "img/sample/img165.png",
            "img/sample/img166.png",
            "img/sample/img167.png",
            "img/sample/img168.png",
            "img/sample/img169.png",
            "img/sample/img170.png",
            "img/sample/img171.png",
            "img/sample/img172.png",
            "img/sample/img173.png",
            "img/sample/img174.png",
            "img/sample/img175.png",
            "img/sample/img176.png",
            "img/sample/img177.png",
            "img/sample/img178.png",
            "img/sample/img179.png",
            "img/sample/img180.png",
            "img/sample/img181.png",
            "img/sample/img182.png",
            "img/sample/img183.png",
            "img/sample/img184.png",
            "img/sample/img185.png",
            "img/sample/img186.png",
            "img/sample/img187.png",
            "img/sample/img188.png",
            "img/sample/img189.png",
            "img/sample/img190.png",
            "img/sample/img191.png",
            "img/sample/img192.png",
            "img/sample/img193.png",
            "img/sample/img194.png",
            "img/sample/img195.png",
            "img/sample/img196.png",
            "img/sample/img197.png",
            "img/sample/img198.png",
            "img/sample/img199.png",
            "img/sample/img200.png",
            "img/sample/img201.png",
            "img/sample/img202.png",
            "img/sample/img203.png",
            "img/sample/img204.png",
            "img/sample/img205.png",
            "img/sample/img206.png",
            "img/sample/img207.png",
            "img/sample/img208.png",
            "img/sample/img209.png",
            "img/sample/img210.png",
            "img/sample/img211.png",
            "img/sample/img212.png",
            "img/sample/img213.png",
            "img/sample/img214.png",
            "img/sample/img215.png",
            "img/sample/img216.png",
            "img/sample/img217.png",
            "img/sample/img218.png",
            "img/sample/img219.png",
            "img/sample/img220.png",
            "img/sample/img221.png",
            "img/sample/img222.png",
            "img/sample/img223.png",
            "img/sample/img224.png",
            "img/sample/img225.png",
            "img/sample/img226.png",
            "img/sample/img227.png",
            "img/sample/img228.png",
            "img/sample/img229.png",
            "img/sample/img230.png",
            "img/sample/img231.png",
            "img/sample/img232.png",
            "img/sample/img233.png",
            "img/sample/img234.png",
            "img/sample/img235.png",
            "img/sample/img236.png",
            "img/sample/img237.png",
            "img/sample/img238.png",
            "img/sample/img239.png",
            "img/sample/img240.png",
            "img/sample/img241.png",
            "img/sample/img242.png",
            "img/sample/img243.png",
            "img/sample/img244.png",
            "img/sample/img245.png",
            "img/sample/img246.png",
            "img/sample/img247.png",
            "img/sample/img248.png",
            "img/sample/img249.png",
            "img/sample/img250.png",
            "img/sample/img251.png",
            "img/sample/img252.png",
            "img/sample/img253.png",
            "img/sample/img254.png",
            "img/sample/img255.png",
            "img/sample/img256.png",
            "img/sample/img257.png",
            "img/sample/img258.png",
            "img/sample/img259.png",
            "img/sample/img260.png",
            "img/sample/img261.png",
            "img/sample/img262.png",
            "img/sample/img263.png",
            "img/sample/img264.png",
            "img/sample/img265.png",
            "img/sample/img266.png",
            "img/sample/img267.png",
            "img/sample/img268.png",
            "img/sample/img269.png",
            "img/sample/img270.png",
            "img/sample/img271.png",
            "img/sample/img272.png",
            "img/sample/img273.png",
            "img/sample/img274.png",
            "img/sample/img275.png",
            "img/sample/img276.png",
            "img/sample/img277.png",
            "img/sample/img278.png",
            "img/sample/img279.png",
            "img/sample/img280.png",
            "img/sample/img281.png",
            "img/sample/img282.png",
            "img/sample/img283.png",
            "img/sample/img284.png",
            "img/sample/img285.png",
            "img/sample/img286.png",
            "img/sample/img287.png",
            "img/sample/img288.png",
            "img/sample/img289.png",
            "img/sample/img290.png",
            "img/sample/img291.png",
            "img/sample/img292.png",
            "img/sample/img293.png",
            "img/sample/img294.png",
            "img/sample/img295.png",
            "img/sample/img296.png",
            "img/sample/img297.png",
            "img/sample/img298.png",
            "img/sample/img299.png",
            "img/sample/img300.png",
            "img/sample/img301.png",
            "img/sample/img302.png",
            "img/sample/img303.png",
            "img/sample/img304.png",
            "img/sample/img305.png",
            "img/sample/img306.png",
            "img/sample/img307.png",
            "img/sample/img308.png",
            "img/sample/img309.png",
            "img/sample/img310.png",
            "img/sample/img311.png",
            "img/sample/img312.png",
            "img/sample/img313.png",
            "img/sample/img314.png",
            "img/sample/img315.png",
            "img/sample/img316.png",
            "img/sample/img317.png",
            "img/sample/img318.png",
            "img/sample/img319.png",
            "img/sample/img320.png",
            "img/sample/img321.png",
            "img/sample/img322.png",
            "img/sample/img323.png",
            "img/sample/img324.png",
            "img/sample/img325.png",
            "img/sample/img326.png",
            "img/sample/img327.png",
            "img/sample/img328.png",
            "img/sample/img329.png",
            "img/sample/img330.png",
            "img/sample/img331.png",
            "img/sample/img332.png",
            "img/sample/img333.png",
            "img/sample/img334.png",
            "img/sample/img335.png",
            "img/sample/img336.png",
            "img/sample/img337.png",
            "img/sample/img338.png",
            "img/sample/img339.png",
            "img/sample/img340.png",
            "img/sample/img341.png",
            "img/sample/img342.png",
            "img/sample/img343.png",
            "img/sample/img344.png",
            "img/sample/img345.png",
            "img/sample/img346.png",
            "img/sample/img347.png",
            "img/sample/img348.png",
            "img/sample/img349.png",
            "img/sample/img350.png",
            "img/sample/img351.png",
            "img/sample/img352.png",
            "img/sample/img353.png",
            "img/sample/img354.png",
            "img/sample/img355.png",
            "img/sample/img356.png",
            "img/sample/img357.png",
            "img/sample/img358.png",
            "img/sample/img359.png",
            "img/sample/img360.png",
            "img/sample/img361.png",
            "img/sample/img362.png",
            "img/sample/img363.png",
            "img/sample/img364.png",
            "img/sample/img365.png",
            "img/sample/img366.png",
            "img/sample/img367.png",
            "img/sample/img368.png",
            "img/sample/img369.png",
            "img/sample/img370.png",
            "img/sample/img371.png",
            "img/sample/img372.png",
            "img/sample/img373.png",
            "img/sample/img374.png",
            "img/sample/img375.png",
            "img/sample/img376.png",
            "img/sample/img377.png",
            "img/sample/img378.png",
            "img/sample/img379.png",
            "img/sample/img380.png",
            "img/sample/img381.png",
            "img/sample/img382.png",
            "img/sample/img383.png",
            "img/sample/img384.png",
            "img/sample/img385.png",
            "img/sample/img386.png",
            "img/sample/img387.png",
            "img/sample/img388.png",
            "img/sample/img389.png",
            "img/sample/img390.png",
            "img/sample/img391.png",
            "img/sample/img392.png",
            "img/sample/img393.png",
            "img/sample/img394.png",
            "img/sample/img395.png",
            "img/sample/img396.png",
            "img/sample/img397.png",
            "img/sample/img398.png",
            "img/sample/img399.png",
            "img/sample/img400.png"]


        $scope.current = $scope.images[parseInt(i)];

        console.log("The user id is: " + user.id);

        $scope.solved = function (){
            $scope.toClear = "";
            document.getElementById("textInput").value = "";
            i = parseInt(i) + 1;
            $scope.current = $scope.images[parseInt(i)];
            $http.get("js/users.json").success(function(userdata){
                console.log("http success for users!!");
                $scope.data = userdata;
                console.log(userdata)
                $scope.data1 = $scope.data[1];
                console.log("My Username is: " + $scope.data[0].username);
                console.log("The name is: " + user.id);
                if ($scope.data[0].id == user.id)
                    $scope.DataNeeded = $scope.data[0];
                else if ($scope.data[1].id == user.id)
                    $scope.DataNeeded = $scope.data[1];
                else if ($scope.data[2].id == user.id)
                    $scope.DataNeeded = $scope.data[2];
                console.log("My correct Username is: " + $scope.DataNeeded.username);
                $scope.DataNeeded.coins = $scope.DataNeeded.coins + 10;

                var myPopup = $ionicPopup.show(
                    {
                        title: "شكرا على مساهمتكم",
                        subtitle: "لقد تم منح 10 قطع نقدية",
                        scope: $scope,
                    })
                $timeout(function()
                {
                    myPopup.close();
                }, 500)


            }).error(function(err){
                console.log("Error " + err);
            });

        }

        $scope.failed = function (){
            $scope.toClear = "";
            document.getElementById("textInput").value = "";
            i = parseInt(i) + 1;
            $scope.current = $scope.images[parseInt(i)];
            var myPopup = $ionicPopup.show(
                {
                    title: "اعتذارنا",
                    subtitle: "كان هذا السؤال تخطي",
                    scope: $scope,
                })
            $timeout(function()
            {
                myPopup.close();
            }, 500)
        }

    })

.controller('ActivityCtrl', function($scope, $stateParams, $timeout, ionicMaterialMotion, ionicMaterialInk) {
    $scope.$parent.showHeader();
    $scope.$parent.clearFabs();
    $scope.isExpanded = true;
    $scope.$parent.setExpanded(true);
    $scope.$parent.setHeaderFab('right');

    $timeout(function() {
        ionicMaterialMotion.fadeSlideIn({
            selector: '.animate-fade-slide-in .item'
        });
    }, 200);

    // Activate ink for controller
    ionicMaterialInk.displayEffect();
})

.controller('GalleryCtrl', function($scope, $stateParams, $timeout, ionicMaterialInk, ionicMaterialMotion) {
    $scope.$parent.showHeader();
    $scope.$parent.clearFabs();
    $scope.isExpanded = true;
    $scope.$parent.setExpanded(true);
    $scope.$parent.setHeaderFab(false);

    // Activate ink for controller
    ionicMaterialInk.displayEffect();

    ionicMaterialMotion.pushDown({
        selector: '.push-down'
    });
    ionicMaterialMotion.fadeSlideInRight({
        selector: '.animate-fade-slide-in .item'
    });

})

;
